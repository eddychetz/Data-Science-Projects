```python
# importing datetime module for now() 
import datetime as dt
    
# using now() to get current time 
current_time = dt.datetime.now() 

print ("Date :{}/{}/{}" .format(current_time.day, current_time.month, current_time.year))
```

    Date :7/12/2021
    

# Breast Cancer Prediction Using Machine-Learning Models

======================================================================================================================

**Objective :** 

- This analysis aims to observe which features are most helpful in predicting malignant or benign cancer and to see general trends that may aid us in model selection and hyper parameter selection. The goal is to **classify whether the breast cancer is benign or malignant**. To achieve this i have used **machine learning classification methods** to fit a function that can predict the discrete class of new input.

======================================================================================================================

- **Structure of the Examination Project :**
1. Importing Dependencies (library & packages)
2. Data Preparation --> (Load And Check Data)
3. Data Exploration & Analysis
4. Data Partitioning & Feature scaling
5. Machine Learning Model Selection & Performance Evaluation
   - Logistic Regression
   - Random Forest
   - Gaussian Naive Bayes
   - Decision Tree
   - K Nearest Neighbor
   
- Perform Comparative Analysis of each & every **5 classification algorithms** & then conclude to the best-model.

======================================================================================================================

#### 1. Importing Dependencies [4]

- We will first go with importing the necessary libraries and import our dataset to jupyter notebook.

<div class="alert alert-danger alertdanger" style="margin-top: 20px">
<p><b>1a.</b> Import libraries for data manipulation? <b>2 marks</b></p>
</div>


```python
import warnings 
warnings.filterwarnings('ignore') # optional to handle warnings

import numpy as np 
import pandas as pd
```

<div class="alert alert-danger alertdanger" style="margin-top: 20px">
<p><b>1b.</b> Import libraries for data visualization? <b>2 marks</b></p>
</div>


```python
import matplotlib.pyplot as plt
import seaborn as sns 
```

======================================================================================================================
#### 2. Data preparation (Load & Check Data) [12]

<div class="alert alert-danger alertdanger" style="margin-top: 20px">
<p><b>2a.</b> Import dataset and view first 5 rows? <b>2 marks</b></p>
</div>


```python
# 2 marks
df = pd.read_csv("data/breast_cancer.csv")
df.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>diagnosis</th>
      <th>radius_mean</th>
      <th>texture_mean</th>
      <th>perimeter_mean</th>
      <th>area_mean</th>
      <th>smoothness_mean</th>
      <th>compactness_mean</th>
      <th>concavity_mean</th>
      <th>concave points_mean</th>
      <th>...</th>
      <th>texture_worst</th>
      <th>perimeter_worst</th>
      <th>area_worst</th>
      <th>smoothness_worst</th>
      <th>compactness_worst</th>
      <th>concavity_worst</th>
      <th>concave points_worst</th>
      <th>symmetry_worst</th>
      <th>fractal_dimension_worst</th>
      <th>Unnamed: 32</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>842302</td>
      <td>M</td>
      <td>17.99</td>
      <td>10.38</td>
      <td>122.80</td>
      <td>1001.0</td>
      <td>0.11840</td>
      <td>0.27760</td>
      <td>0.3001</td>
      <td>0.14710</td>
      <td>...</td>
      <td>17.33</td>
      <td>184.60</td>
      <td>2019.0</td>
      <td>0.1622</td>
      <td>0.6656</td>
      <td>0.7119</td>
      <td>0.2654</td>
      <td>0.4601</td>
      <td>0.11890</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>842517</td>
      <td>M</td>
      <td>20.57</td>
      <td>17.77</td>
      <td>132.90</td>
      <td>1326.0</td>
      <td>0.08474</td>
      <td>0.07864</td>
      <td>0.0869</td>
      <td>0.07017</td>
      <td>...</td>
      <td>23.41</td>
      <td>158.80</td>
      <td>1956.0</td>
      <td>0.1238</td>
      <td>0.1866</td>
      <td>0.2416</td>
      <td>0.1860</td>
      <td>0.2750</td>
      <td>0.08902</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>84300903</td>
      <td>M</td>
      <td>19.69</td>
      <td>21.25</td>
      <td>130.00</td>
      <td>1203.0</td>
      <td>0.10960</td>
      <td>0.15990</td>
      <td>0.1974</td>
      <td>0.12790</td>
      <td>...</td>
      <td>25.53</td>
      <td>152.50</td>
      <td>1709.0</td>
      <td>0.1444</td>
      <td>0.4245</td>
      <td>0.4504</td>
      <td>0.2430</td>
      <td>0.3613</td>
      <td>0.08758</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>84348301</td>
      <td>M</td>
      <td>11.42</td>
      <td>20.38</td>
      <td>77.58</td>
      <td>386.1</td>
      <td>0.14250</td>
      <td>0.28390</td>
      <td>0.2414</td>
      <td>0.10520</td>
      <td>...</td>
      <td>26.50</td>
      <td>98.87</td>
      <td>567.7</td>
      <td>0.2098</td>
      <td>0.8663</td>
      <td>0.6869</td>
      <td>0.2575</td>
      <td>0.6638</td>
      <td>0.17300</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>84358402</td>
      <td>M</td>
      <td>20.29</td>
      <td>14.34</td>
      <td>135.10</td>
      <td>1297.0</td>
      <td>0.10030</td>
      <td>0.13280</td>
      <td>0.1980</td>
      <td>0.10430</td>
      <td>...</td>
      <td>16.67</td>
      <td>152.20</td>
      <td>1575.0</td>
      <td>0.1374</td>
      <td>0.2050</td>
      <td>0.4000</td>
      <td>0.1625</td>
      <td>0.2364</td>
      <td>0.07678</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 33 columns</p>
</div>



<div class="alert alert-danger alertdanger" style="margin-top: 20px">
<p><b>2b.</b> Determine the dimension of breast cancer dataset and comment? <b>2 marks</b></p>
</div>


```python
# 2 marks
print('The breast cancer dataset has {} rows and {} columns.'.format(df.shape[0],df.shape[1]))
```

    The breast cancer dataset has 569 rows and 33 columns.
    

<div class="alert alert-danger alertdanger" style="margin-top: 20px">
    <p><b>2c.</b> Check for missing values and comment? <b>2 marks</b></p>
</div>

- We can find any missing or null data points of the data set (if there is any) using the following `pandas` function.


```python
# your code here [1]
print(df.isnull().sum().sum())
```

    569
    

- The dataset has 569 missing values on `Unnamed: 32` feature. **[1]**

<div class="alert alert-danger alertdanger" style="margin-top: 20px">
<p><b>2d.</b> Drop irrelevant columns from the breast cancer dataset which can not be used to predict breast cancer? <b>3 marks</b></p>
</div>


```python
# dropping the unwanted features for prediction [2]
df = df.drop(["Unnamed: 32","id"], axis=1, inplace=False)   
```

- `Unnamed: 32` and `id` are two columns to be dropped as these can not be used to predict breast cancer.**[1]**

<div class="alert alert-danger alertdanger" style="margin-top: 20px">
<p><b>2e.</b> Check for duplicate rows and comment. <b>3 marks</b></p>
</div>


```python
duplicated = df.duplicated()
print('-Statement:\n\n There are duplicate rows in the dataset.(', duplicated.unique()[0],')')
print('\n-No duplicate rows in the dataset.')
```

    -Statement:
    
     There are duplicate rows in the dataset.( False )
    
    -No duplicate rows in the dataset.
    

======================================================================================================================
#### 3. Data Exploration & Analysis [34]

<div class="alert alert-danger alertdanger" style="margin-top: 20px">
<p><b>3a.</b> Rename the 'diagnosis' column to 'label'? <b>11 marks</b></p>
</div>

- i. Rename `diagnosis` to `label`. [2]
- ii. Plot a `countplot` of the label to show counts for each class, include the `chart title` and `set_theme` style to `darkgrid`.[3]
- iii. Convert `string` expressions to `int` because it will be necessary when making trains. `Malignant = 1` ,`Benign = 0` using `LabelEncoder` function from `sklearn`. [3]
- iv. Confirm number of `malignant` and `benign` cases and comment. [3]

`Diagnosis` is the column which we are going to predict , which says if the cancer is `M = malignant` or `B = benign`.


```python
 # i. renaming the title of properties as per need of prediction 2 marks
df = df.rename(columns = {"diagnosis" : "label"})  
```


```python
# ii. Countplot 3 marks
sns.set_theme(style="darkgrid")
sns.countplot(df['label'], label="count")
plt.title("Bar chart for unique labels' counts in the dataset.")
plt.show()
```


    
![png](output_28_0.png)
    


Categorical data are variables that contain label values rather than numeric values.The number of possible values is often limited to a fixed set.You need to change these into some numeric codes to represent the strings.


```python
# iii. Label encoding [3]
from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
df['label'] = le.fit_transform(df['label'])
```


```python
# iv. Confirming counts of respective classes [3]
df.label.value_counts()[0:]
```




    0    357
    1    212
    Name: label, dtype: int64



- We can identify that out of the `569` persons, `357` are labeled as B (benign) and `212` as M (malignant).
___

- **Variable/Attribute Description** \
Label--> **(M= malignant , B = Benign)**

- Ten real-valued features are computed for each cell nucleus:

1. radius (mean of distances from center to points on the perimeter)
2. texture (standard deviation of gray-scale values)
3. perimeter
4. area
5. smoothness (local variation in radius lengths)
6. compactness (perimeter^2 / area - 1.0)
7. concavity (severity of concave portions of the contour)
8. concave points (number of concave portions of the contour)
9. symmetry
10. fractal dimension ("coastline approximation" - 1)
___
- The mean, standard error and “worst” or largest (mean of the three largest values) of these features were computed for each image, resulting in 30 features. For instance, field 3 is Mean Radius, field 13 is Radius SE, field 23 is Worst Radius.

<div class="alert alert-danger alertdanger" style="margin-top: 20px">
<p><b>3b.</b> Compute a 5-number summary of all features against the label. <i>(i.e. min, 25%, 50%, 75%, max). </i><b>2 marks</b></p>
</div>


```python
# 5 number summary [2]
df.describe()[3:]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>label</th>
      <th>radius_mean</th>
      <th>texture_mean</th>
      <th>perimeter_mean</th>
      <th>area_mean</th>
      <th>smoothness_mean</th>
      <th>compactness_mean</th>
      <th>concavity_mean</th>
      <th>concave points_mean</th>
      <th>symmetry_mean</th>
      <th>...</th>
      <th>radius_worst</th>
      <th>texture_worst</th>
      <th>perimeter_worst</th>
      <th>area_worst</th>
      <th>smoothness_worst</th>
      <th>compactness_worst</th>
      <th>concavity_worst</th>
      <th>concave points_worst</th>
      <th>symmetry_worst</th>
      <th>fractal_dimension_worst</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>min</th>
      <td>0.0</td>
      <td>6.981</td>
      <td>9.71</td>
      <td>43.79</td>
      <td>143.5</td>
      <td>0.05263</td>
      <td>0.01938</td>
      <td>0.00000</td>
      <td>0.00000</td>
      <td>0.1060</td>
      <td>...</td>
      <td>7.93</td>
      <td>12.02</td>
      <td>50.41</td>
      <td>185.2</td>
      <td>0.07117</td>
      <td>0.02729</td>
      <td>0.0000</td>
      <td>0.00000</td>
      <td>0.1565</td>
      <td>0.05504</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>0.0</td>
      <td>11.700</td>
      <td>16.17</td>
      <td>75.17</td>
      <td>420.3</td>
      <td>0.08637</td>
      <td>0.06492</td>
      <td>0.02956</td>
      <td>0.02031</td>
      <td>0.1619</td>
      <td>...</td>
      <td>13.01</td>
      <td>21.08</td>
      <td>84.11</td>
      <td>515.3</td>
      <td>0.11660</td>
      <td>0.14720</td>
      <td>0.1145</td>
      <td>0.06493</td>
      <td>0.2504</td>
      <td>0.07146</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>0.0</td>
      <td>13.370</td>
      <td>18.84</td>
      <td>86.24</td>
      <td>551.1</td>
      <td>0.09587</td>
      <td>0.09263</td>
      <td>0.06154</td>
      <td>0.03350</td>
      <td>0.1792</td>
      <td>...</td>
      <td>14.97</td>
      <td>25.41</td>
      <td>97.66</td>
      <td>686.5</td>
      <td>0.13130</td>
      <td>0.21190</td>
      <td>0.2267</td>
      <td>0.09993</td>
      <td>0.2822</td>
      <td>0.08004</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>1.0</td>
      <td>15.780</td>
      <td>21.80</td>
      <td>104.10</td>
      <td>782.7</td>
      <td>0.10530</td>
      <td>0.13040</td>
      <td>0.13070</td>
      <td>0.07400</td>
      <td>0.1957</td>
      <td>...</td>
      <td>18.79</td>
      <td>29.72</td>
      <td>125.40</td>
      <td>1084.0</td>
      <td>0.14600</td>
      <td>0.33910</td>
      <td>0.3829</td>
      <td>0.16140</td>
      <td>0.3179</td>
      <td>0.09208</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1.0</td>
      <td>28.110</td>
      <td>39.28</td>
      <td>188.50</td>
      <td>2501.0</td>
      <td>0.16340</td>
      <td>0.34540</td>
      <td>0.42680</td>
      <td>0.20120</td>
      <td>0.3040</td>
      <td>...</td>
      <td>36.04</td>
      <td>49.54</td>
      <td>251.20</td>
      <td>4254.0</td>
      <td>0.22260</td>
      <td>1.05800</td>
      <td>1.2520</td>
      <td>0.29100</td>
      <td>0.6638</td>
      <td>0.20750</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 31 columns</p>
</div>



<div class="alert alert-danger alertdanger" style="margin-top: 20px">
<p><b>3c.</b>  Compute correlation of the entire dataset and observe features with 'corr value' greater than '60%'. <b>4 marks</b></p>
</div>


```python
#correlation plot [4]
corr = df.corr() 
corr
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>label</th>
      <th>radius_mean</th>
      <th>texture_mean</th>
      <th>perimeter_mean</th>
      <th>area_mean</th>
      <th>smoothness_mean</th>
      <th>compactness_mean</th>
      <th>concavity_mean</th>
      <th>concave points_mean</th>
      <th>symmetry_mean</th>
      <th>...</th>
      <th>radius_worst</th>
      <th>texture_worst</th>
      <th>perimeter_worst</th>
      <th>area_worst</th>
      <th>smoothness_worst</th>
      <th>compactness_worst</th>
      <th>concavity_worst</th>
      <th>concave points_worst</th>
      <th>symmetry_worst</th>
      <th>fractal_dimension_worst</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>label</th>
      <td>1.000000</td>
      <td>0.730029</td>
      <td>0.415185</td>
      <td>0.742636</td>
      <td>0.708984</td>
      <td>0.358560</td>
      <td>0.596534</td>
      <td>0.696360</td>
      <td>0.776614</td>
      <td>0.330499</td>
      <td>...</td>
      <td>0.776454</td>
      <td>0.456903</td>
      <td>0.782914</td>
      <td>0.733825</td>
      <td>0.421465</td>
      <td>0.590998</td>
      <td>0.659610</td>
      <td>0.793566</td>
      <td>0.416294</td>
      <td>0.323872</td>
    </tr>
    <tr>
      <th>radius_mean</th>
      <td>0.730029</td>
      <td>1.000000</td>
      <td>0.323782</td>
      <td>0.997855</td>
      <td>0.987357</td>
      <td>0.170581</td>
      <td>0.506124</td>
      <td>0.676764</td>
      <td>0.822529</td>
      <td>0.147741</td>
      <td>...</td>
      <td>0.969539</td>
      <td>0.297008</td>
      <td>0.965137</td>
      <td>0.941082</td>
      <td>0.119616</td>
      <td>0.413463</td>
      <td>0.526911</td>
      <td>0.744214</td>
      <td>0.163953</td>
      <td>0.007066</td>
    </tr>
    <tr>
      <th>texture_mean</th>
      <td>0.415185</td>
      <td>0.323782</td>
      <td>1.000000</td>
      <td>0.329533</td>
      <td>0.321086</td>
      <td>-0.023389</td>
      <td>0.236702</td>
      <td>0.302418</td>
      <td>0.293464</td>
      <td>0.071401</td>
      <td>...</td>
      <td>0.352573</td>
      <td>0.912045</td>
      <td>0.358040</td>
      <td>0.343546</td>
      <td>0.077503</td>
      <td>0.277830</td>
      <td>0.301025</td>
      <td>0.295316</td>
      <td>0.105008</td>
      <td>0.119205</td>
    </tr>
    <tr>
      <th>perimeter_mean</th>
      <td>0.742636</td>
      <td>0.997855</td>
      <td>0.329533</td>
      <td>1.000000</td>
      <td>0.986507</td>
      <td>0.207278</td>
      <td>0.556936</td>
      <td>0.716136</td>
      <td>0.850977</td>
      <td>0.183027</td>
      <td>...</td>
      <td>0.969476</td>
      <td>0.303038</td>
      <td>0.970387</td>
      <td>0.941550</td>
      <td>0.150549</td>
      <td>0.455774</td>
      <td>0.563879</td>
      <td>0.771241</td>
      <td>0.189115</td>
      <td>0.051019</td>
    </tr>
    <tr>
      <th>area_mean</th>
      <td>0.708984</td>
      <td>0.987357</td>
      <td>0.321086</td>
      <td>0.986507</td>
      <td>1.000000</td>
      <td>0.177028</td>
      <td>0.498502</td>
      <td>0.685983</td>
      <td>0.823269</td>
      <td>0.151293</td>
      <td>...</td>
      <td>0.962746</td>
      <td>0.287489</td>
      <td>0.959120</td>
      <td>0.959213</td>
      <td>0.123523</td>
      <td>0.390410</td>
      <td>0.512606</td>
      <td>0.722017</td>
      <td>0.143570</td>
      <td>0.003738</td>
    </tr>
    <tr>
      <th>smoothness_mean</th>
      <td>0.358560</td>
      <td>0.170581</td>
      <td>-0.023389</td>
      <td>0.207278</td>
      <td>0.177028</td>
      <td>1.000000</td>
      <td>0.659123</td>
      <td>0.521984</td>
      <td>0.553695</td>
      <td>0.557775</td>
      <td>...</td>
      <td>0.213120</td>
      <td>0.036072</td>
      <td>0.238853</td>
      <td>0.206718</td>
      <td>0.805324</td>
      <td>0.472468</td>
      <td>0.434926</td>
      <td>0.503053</td>
      <td>0.394309</td>
      <td>0.499316</td>
    </tr>
    <tr>
      <th>compactness_mean</th>
      <td>0.596534</td>
      <td>0.506124</td>
      <td>0.236702</td>
      <td>0.556936</td>
      <td>0.498502</td>
      <td>0.659123</td>
      <td>1.000000</td>
      <td>0.883121</td>
      <td>0.831135</td>
      <td>0.602641</td>
      <td>...</td>
      <td>0.535315</td>
      <td>0.248133</td>
      <td>0.590210</td>
      <td>0.509604</td>
      <td>0.565541</td>
      <td>0.865809</td>
      <td>0.816275</td>
      <td>0.815573</td>
      <td>0.510223</td>
      <td>0.687382</td>
    </tr>
    <tr>
      <th>concavity_mean</th>
      <td>0.696360</td>
      <td>0.676764</td>
      <td>0.302418</td>
      <td>0.716136</td>
      <td>0.685983</td>
      <td>0.521984</td>
      <td>0.883121</td>
      <td>1.000000</td>
      <td>0.921391</td>
      <td>0.500667</td>
      <td>...</td>
      <td>0.688236</td>
      <td>0.299879</td>
      <td>0.729565</td>
      <td>0.675987</td>
      <td>0.448822</td>
      <td>0.754968</td>
      <td>0.884103</td>
      <td>0.861323</td>
      <td>0.409464</td>
      <td>0.514930</td>
    </tr>
    <tr>
      <th>concave points_mean</th>
      <td>0.776614</td>
      <td>0.822529</td>
      <td>0.293464</td>
      <td>0.850977</td>
      <td>0.823269</td>
      <td>0.553695</td>
      <td>0.831135</td>
      <td>0.921391</td>
      <td>1.000000</td>
      <td>0.462497</td>
      <td>...</td>
      <td>0.830318</td>
      <td>0.292752</td>
      <td>0.855923</td>
      <td>0.809630</td>
      <td>0.452753</td>
      <td>0.667454</td>
      <td>0.752399</td>
      <td>0.910155</td>
      <td>0.375744</td>
      <td>0.368661</td>
    </tr>
    <tr>
      <th>symmetry_mean</th>
      <td>0.330499</td>
      <td>0.147741</td>
      <td>0.071401</td>
      <td>0.183027</td>
      <td>0.151293</td>
      <td>0.557775</td>
      <td>0.602641</td>
      <td>0.500667</td>
      <td>0.462497</td>
      <td>1.000000</td>
      <td>...</td>
      <td>0.185728</td>
      <td>0.090651</td>
      <td>0.219169</td>
      <td>0.177193</td>
      <td>0.426675</td>
      <td>0.473200</td>
      <td>0.433721</td>
      <td>0.430297</td>
      <td>0.699826</td>
      <td>0.438413</td>
    </tr>
    <tr>
      <th>fractal_dimension_mean</th>
      <td>-0.012838</td>
      <td>-0.311631</td>
      <td>-0.076437</td>
      <td>-0.261477</td>
      <td>-0.283110</td>
      <td>0.584792</td>
      <td>0.565369</td>
      <td>0.336783</td>
      <td>0.166917</td>
      <td>0.479921</td>
      <td>...</td>
      <td>-0.253691</td>
      <td>-0.051269</td>
      <td>-0.205151</td>
      <td>-0.231854</td>
      <td>0.504942</td>
      <td>0.458798</td>
      <td>0.346234</td>
      <td>0.175325</td>
      <td>0.334019</td>
      <td>0.767297</td>
    </tr>
    <tr>
      <th>radius_se</th>
      <td>0.567134</td>
      <td>0.679090</td>
      <td>0.275869</td>
      <td>0.691765</td>
      <td>0.732562</td>
      <td>0.301467</td>
      <td>0.497473</td>
      <td>0.631925</td>
      <td>0.698050</td>
      <td>0.303379</td>
      <td>...</td>
      <td>0.715065</td>
      <td>0.194799</td>
      <td>0.719684</td>
      <td>0.751548</td>
      <td>0.141919</td>
      <td>0.287103</td>
      <td>0.380585</td>
      <td>0.531062</td>
      <td>0.094543</td>
      <td>0.049559</td>
    </tr>
    <tr>
      <th>texture_se</th>
      <td>-0.008303</td>
      <td>-0.097317</td>
      <td>0.386358</td>
      <td>-0.086761</td>
      <td>-0.066280</td>
      <td>0.068406</td>
      <td>0.046205</td>
      <td>0.076218</td>
      <td>0.021480</td>
      <td>0.128053</td>
      <td>...</td>
      <td>-0.111690</td>
      <td>0.409003</td>
      <td>-0.102242</td>
      <td>-0.083195</td>
      <td>-0.073658</td>
      <td>-0.092439</td>
      <td>-0.068956</td>
      <td>-0.119638</td>
      <td>-0.128215</td>
      <td>-0.045655</td>
    </tr>
    <tr>
      <th>perimeter_se</th>
      <td>0.556141</td>
      <td>0.674172</td>
      <td>0.281673</td>
      <td>0.693135</td>
      <td>0.726628</td>
      <td>0.296092</td>
      <td>0.548905</td>
      <td>0.660391</td>
      <td>0.710650</td>
      <td>0.313893</td>
      <td>...</td>
      <td>0.697201</td>
      <td>0.200371</td>
      <td>0.721031</td>
      <td>0.730713</td>
      <td>0.130054</td>
      <td>0.341919</td>
      <td>0.418899</td>
      <td>0.554897</td>
      <td>0.109930</td>
      <td>0.085433</td>
    </tr>
    <tr>
      <th>area_se</th>
      <td>0.548236</td>
      <td>0.735864</td>
      <td>0.259845</td>
      <td>0.744983</td>
      <td>0.800086</td>
      <td>0.246552</td>
      <td>0.455653</td>
      <td>0.617427</td>
      <td>0.690299</td>
      <td>0.223970</td>
      <td>...</td>
      <td>0.757373</td>
      <td>0.196497</td>
      <td>0.761213</td>
      <td>0.811408</td>
      <td>0.125389</td>
      <td>0.283257</td>
      <td>0.385100</td>
      <td>0.538166</td>
      <td>0.074126</td>
      <td>0.017539</td>
    </tr>
    <tr>
      <th>smoothness_se</th>
      <td>-0.067016</td>
      <td>-0.222600</td>
      <td>0.006614</td>
      <td>-0.202694</td>
      <td>-0.166777</td>
      <td>0.332375</td>
      <td>0.135299</td>
      <td>0.098564</td>
      <td>0.027653</td>
      <td>0.187321</td>
      <td>...</td>
      <td>-0.230691</td>
      <td>-0.074743</td>
      <td>-0.217304</td>
      <td>-0.182195</td>
      <td>0.314457</td>
      <td>-0.055558</td>
      <td>-0.058298</td>
      <td>-0.102007</td>
      <td>-0.107342</td>
      <td>0.101480</td>
    </tr>
    <tr>
      <th>compactness_se</th>
      <td>0.292999</td>
      <td>0.206000</td>
      <td>0.191975</td>
      <td>0.250744</td>
      <td>0.212583</td>
      <td>0.318943</td>
      <td>0.738722</td>
      <td>0.670279</td>
      <td>0.490424</td>
      <td>0.421659</td>
      <td>...</td>
      <td>0.204607</td>
      <td>0.143003</td>
      <td>0.260516</td>
      <td>0.199371</td>
      <td>0.227394</td>
      <td>0.678780</td>
      <td>0.639147</td>
      <td>0.483208</td>
      <td>0.277878</td>
      <td>0.590973</td>
    </tr>
    <tr>
      <th>concavity_se</th>
      <td>0.253730</td>
      <td>0.194204</td>
      <td>0.143293</td>
      <td>0.228082</td>
      <td>0.207660</td>
      <td>0.248396</td>
      <td>0.570517</td>
      <td>0.691270</td>
      <td>0.439167</td>
      <td>0.342627</td>
      <td>...</td>
      <td>0.186904</td>
      <td>0.100241</td>
      <td>0.226680</td>
      <td>0.188353</td>
      <td>0.168481</td>
      <td>0.484858</td>
      <td>0.662564</td>
      <td>0.440472</td>
      <td>0.197788</td>
      <td>0.439329</td>
    </tr>
    <tr>
      <th>concave points_se</th>
      <td>0.408042</td>
      <td>0.376169</td>
      <td>0.163851</td>
      <td>0.407217</td>
      <td>0.372320</td>
      <td>0.380676</td>
      <td>0.642262</td>
      <td>0.683260</td>
      <td>0.615634</td>
      <td>0.393298</td>
      <td>...</td>
      <td>0.358127</td>
      <td>0.086741</td>
      <td>0.394999</td>
      <td>0.342271</td>
      <td>0.215351</td>
      <td>0.452888</td>
      <td>0.549592</td>
      <td>0.602450</td>
      <td>0.143116</td>
      <td>0.310655</td>
    </tr>
    <tr>
      <th>symmetry_se</th>
      <td>-0.006522</td>
      <td>-0.104321</td>
      <td>0.009127</td>
      <td>-0.081629</td>
      <td>-0.072497</td>
      <td>0.200774</td>
      <td>0.229977</td>
      <td>0.178009</td>
      <td>0.095351</td>
      <td>0.449137</td>
      <td>...</td>
      <td>-0.128121</td>
      <td>-0.077473</td>
      <td>-0.103753</td>
      <td>-0.110343</td>
      <td>-0.012662</td>
      <td>0.060255</td>
      <td>0.037119</td>
      <td>-0.030413</td>
      <td>0.389402</td>
      <td>0.078079</td>
    </tr>
    <tr>
      <th>fractal_dimension_se</th>
      <td>0.077972</td>
      <td>-0.042641</td>
      <td>0.054458</td>
      <td>-0.005523</td>
      <td>-0.019887</td>
      <td>0.283607</td>
      <td>0.507318</td>
      <td>0.449301</td>
      <td>0.257584</td>
      <td>0.331786</td>
      <td>...</td>
      <td>-0.037488</td>
      <td>-0.003195</td>
      <td>-0.001000</td>
      <td>-0.022736</td>
      <td>0.170568</td>
      <td>0.390159</td>
      <td>0.379975</td>
      <td>0.215204</td>
      <td>0.111094</td>
      <td>0.591328</td>
    </tr>
    <tr>
      <th>radius_worst</th>
      <td>0.776454</td>
      <td>0.969539</td>
      <td>0.352573</td>
      <td>0.969476</td>
      <td>0.962746</td>
      <td>0.213120</td>
      <td>0.535315</td>
      <td>0.688236</td>
      <td>0.830318</td>
      <td>0.185728</td>
      <td>...</td>
      <td>1.000000</td>
      <td>0.359921</td>
      <td>0.993708</td>
      <td>0.984015</td>
      <td>0.216574</td>
      <td>0.475820</td>
      <td>0.573975</td>
      <td>0.787424</td>
      <td>0.243529</td>
      <td>0.093492</td>
    </tr>
    <tr>
      <th>texture_worst</th>
      <td>0.456903</td>
      <td>0.297008</td>
      <td>0.912045</td>
      <td>0.303038</td>
      <td>0.287489</td>
      <td>0.036072</td>
      <td>0.248133</td>
      <td>0.299879</td>
      <td>0.292752</td>
      <td>0.090651</td>
      <td>...</td>
      <td>0.359921</td>
      <td>1.000000</td>
      <td>0.365098</td>
      <td>0.345842</td>
      <td>0.225429</td>
      <td>0.360832</td>
      <td>0.368366</td>
      <td>0.359755</td>
      <td>0.233027</td>
      <td>0.219122</td>
    </tr>
    <tr>
      <th>perimeter_worst</th>
      <td>0.782914</td>
      <td>0.965137</td>
      <td>0.358040</td>
      <td>0.970387</td>
      <td>0.959120</td>
      <td>0.238853</td>
      <td>0.590210</td>
      <td>0.729565</td>
      <td>0.855923</td>
      <td>0.219169</td>
      <td>...</td>
      <td>0.993708</td>
      <td>0.365098</td>
      <td>1.000000</td>
      <td>0.977578</td>
      <td>0.236775</td>
      <td>0.529408</td>
      <td>0.618344</td>
      <td>0.816322</td>
      <td>0.269493</td>
      <td>0.138957</td>
    </tr>
    <tr>
      <th>area_worst</th>
      <td>0.733825</td>
      <td>0.941082</td>
      <td>0.343546</td>
      <td>0.941550</td>
      <td>0.959213</td>
      <td>0.206718</td>
      <td>0.509604</td>
      <td>0.675987</td>
      <td>0.809630</td>
      <td>0.177193</td>
      <td>...</td>
      <td>0.984015</td>
      <td>0.345842</td>
      <td>0.977578</td>
      <td>1.000000</td>
      <td>0.209145</td>
      <td>0.438296</td>
      <td>0.543331</td>
      <td>0.747419</td>
      <td>0.209146</td>
      <td>0.079647</td>
    </tr>
    <tr>
      <th>smoothness_worst</th>
      <td>0.421465</td>
      <td>0.119616</td>
      <td>0.077503</td>
      <td>0.150549</td>
      <td>0.123523</td>
      <td>0.805324</td>
      <td>0.565541</td>
      <td>0.448822</td>
      <td>0.452753</td>
      <td>0.426675</td>
      <td>...</td>
      <td>0.216574</td>
      <td>0.225429</td>
      <td>0.236775</td>
      <td>0.209145</td>
      <td>1.000000</td>
      <td>0.568187</td>
      <td>0.518523</td>
      <td>0.547691</td>
      <td>0.493838</td>
      <td>0.617624</td>
    </tr>
    <tr>
      <th>compactness_worst</th>
      <td>0.590998</td>
      <td>0.413463</td>
      <td>0.277830</td>
      <td>0.455774</td>
      <td>0.390410</td>
      <td>0.472468</td>
      <td>0.865809</td>
      <td>0.754968</td>
      <td>0.667454</td>
      <td>0.473200</td>
      <td>...</td>
      <td>0.475820</td>
      <td>0.360832</td>
      <td>0.529408</td>
      <td>0.438296</td>
      <td>0.568187</td>
      <td>1.000000</td>
      <td>0.892261</td>
      <td>0.801080</td>
      <td>0.614441</td>
      <td>0.810455</td>
    </tr>
    <tr>
      <th>concavity_worst</th>
      <td>0.659610</td>
      <td>0.526911</td>
      <td>0.301025</td>
      <td>0.563879</td>
      <td>0.512606</td>
      <td>0.434926</td>
      <td>0.816275</td>
      <td>0.884103</td>
      <td>0.752399</td>
      <td>0.433721</td>
      <td>...</td>
      <td>0.573975</td>
      <td>0.368366</td>
      <td>0.618344</td>
      <td>0.543331</td>
      <td>0.518523</td>
      <td>0.892261</td>
      <td>1.000000</td>
      <td>0.855434</td>
      <td>0.532520</td>
      <td>0.686511</td>
    </tr>
    <tr>
      <th>concave points_worst</th>
      <td>0.793566</td>
      <td>0.744214</td>
      <td>0.295316</td>
      <td>0.771241</td>
      <td>0.722017</td>
      <td>0.503053</td>
      <td>0.815573</td>
      <td>0.861323</td>
      <td>0.910155</td>
      <td>0.430297</td>
      <td>...</td>
      <td>0.787424</td>
      <td>0.359755</td>
      <td>0.816322</td>
      <td>0.747419</td>
      <td>0.547691</td>
      <td>0.801080</td>
      <td>0.855434</td>
      <td>1.000000</td>
      <td>0.502528</td>
      <td>0.511114</td>
    </tr>
    <tr>
      <th>symmetry_worst</th>
      <td>0.416294</td>
      <td>0.163953</td>
      <td>0.105008</td>
      <td>0.189115</td>
      <td>0.143570</td>
      <td>0.394309</td>
      <td>0.510223</td>
      <td>0.409464</td>
      <td>0.375744</td>
      <td>0.699826</td>
      <td>...</td>
      <td>0.243529</td>
      <td>0.233027</td>
      <td>0.269493</td>
      <td>0.209146</td>
      <td>0.493838</td>
      <td>0.614441</td>
      <td>0.532520</td>
      <td>0.502528</td>
      <td>1.000000</td>
      <td>0.537848</td>
    </tr>
    <tr>
      <th>fractal_dimension_worst</th>
      <td>0.323872</td>
      <td>0.007066</td>
      <td>0.119205</td>
      <td>0.051019</td>
      <td>0.003738</td>
      <td>0.499316</td>
      <td>0.687382</td>
      <td>0.514930</td>
      <td>0.368661</td>
      <td>0.438413</td>
      <td>...</td>
      <td>0.093492</td>
      <td>0.219122</td>
      <td>0.138957</td>
      <td>0.079647</td>
      <td>0.617624</td>
      <td>0.810455</td>
      <td>0.686511</td>
      <td>0.511114</td>
      <td>0.537848</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
<p>31 rows × 31 columns</p>
</div>



Visualization of data is an imperative aspect to understand data and also to explain the data to another person. Python has several interesting visualization libraries that can help an individual to achieve this.

<div class="alert alert-danger alertdanger" style="margin-top: 20px">
<p><b>3d.</b>  Visualize the correlation between features using heatmap. <b>11 marks</b></p>
</div>

- i. heatmap of all features, include annotations, title and correlation values must be to 2 decimal places. [5]
- ii. heatmap of all features with 60% corr value and above, include annotations, title and correlation values must be to 2 decimal places. [6]


```python
# 5 marks
plt.figure(figsize=(20,10))
sns.heatmap(corr, annot= True, fmt =".2f", cmap = 'Spectral_r')
plt.title("Correlation Between Features")
plt.show()
```


    
![png](output_40_0.png)
    


- First, we set a limit value. Here we set it to `0.6`. We bring the ones whose relationship between features is greater than `|0.6|`.


```python
# 6 marks
threshold = 0.6 
filtre = np.abs(corr["label"]) >= threshold 
corr_features = corr.columns[filtre].tolist()
plt.figure(figsize=(20,10))
sns.heatmap(df[corr_features].corr(), annot = True, fmt = ".2f", cmap = 'Spectral_r')
plt.title("Correlation Between Features w Corr Theshold 0.6")
plt.show()
```


    
![png](output_42_0.png)
    


<div class="alert alert-danger alertdanger" style="margin-top: 20px">
<p><b>3e.</b>  Use pairplot to visualize features with 60% and higher correlation value against the label. <b>3 marks</b></p>
</div>

- set `diag_kind = "kde"`
- set `hue = "label"`


```python
#pairplot for the features with 60% and higher correlation value with the label
sns.pairplot(df[corr_features], diag_kind = "kde", markers = "+", hue = "label")
plt.show()
```


    
![png](output_44_0.png)
    


<div class="alert alert-danger alertdanger" style="margin-top: 20px">
    <p><b>3f.</b> Separate features <b>(X)</b> from labels <b>(y)</b> using <b>60%+</b> correlation features. <b>3 marks</b></p>
</div>


```python
df = df[corr_features]
X = df.drop('label',axis=1)
y = df['label']
```

======================================================================================================================
#### 4. Data Partitioning and Feature Scaling [10]

- **Splitting the dataset :**
The data we use is usually split into training data and test data. The training set contains a known output and the model learns on this data in order to be generalized to other data later on. We have the test dataset (or subset) in order to test our model’s prediction on this subset.
We will do this using `SciKit-Learn` library in Python using the `train_test_split` method.

<div class="alert alert-danger alertdanger" style="margin-top: 20px">
    <p><b>4a.</b> Split the dataset into train and test set using the <b>60%+</b> correlation features. <b>6 marks</b></p>
</div>

- Split into 80-20% 
- Check and verify in `percentages` on the shape of the `X_train` and `X_test` sets.


```python
# importing train_test_split from sklearn
from sklearn.model_selection import train_test_split

# splitting the data to 80-20%
X_train, X_test, y_train, y_test = train_test_split(X.values, y, test_size = 0.2, random_state=0)
print("Train set has: {} ({:.0f}%)" .format(X_train.shape[0], (X_train.shape[0]/X.shape[0])*100), " rows and {}".format(X_train.shape[1]), " columns. \n")
print("Test set has: {} ({:.0f}%)" .format(X_test.shape[0],(X_test.shape[0]/X.shape[0])*100), " rows and {}".format(X_test.shape[1]), " columns. \n")
```

    Train set has: 455 (80%)  rows and 10  columns. 
    
    Test set has: 114 (20%)  rows and 10  columns. 
    
    

<div class="alert alert-danger alertdanger" style="margin-top: 20px">
<p><b>4b.</b>  Scale your features using StandardScaler method. <b>4 marks</b></p>
</div>

We look at the data need for standardization, if there are big differences between the data, standardization is required.

Most of the times, your dataset will contain features highly varying in magnitudes, units and range. But since, most of the machine learning algorithms use Eucledian distance between two data points in their computations. We need to bring all features to the same level of magnitudes. This can be achieved by scaling. This means that you’re transforming your data so that it fits within a specific scale, like `0–100` or `0–1`.
We will use `StandardScaler` method from `SciKit-Learn` library.


```python
# 4 marks
from sklearn.preprocessing import StandardScaler

ss = StandardScaler()

X_train = ss.fit_transform(X_train)
X_test = ss.transform(X_test)

# confirm the results
print(X_train)
```

    [[-1.15036482 -1.12855021 -0.95876358 ... -0.84880771 -0.81232053
      -0.75798367]
     [-0.93798972 -0.94820146 -0.82152548 ... -0.66869703 -0.37504806
      -0.60687023]
     [ 0.574121    0.51394098  0.40858627 ...  0.11388819 -0.18298917
      -0.02371948]
     ...
     [-1.32422924 -1.31754581 -1.04876494 ... -0.75388682 -0.76769066
      -0.97974953]
     [-1.24380987 -1.28007609 -1.02221174 ... -0.98572598 -1.34136004
      -1.75401433]
     [-0.73694129 -0.71226578 -0.69966029 ... -0.69481734  0.47893704
      -0.27460457]]
    

======================================================================================================================
#### 5. Machine Learning Models Selection and Performance Evaluation [40]

This phase is known as Algorithm selection for Predicting the best results.

You are required to train the following models:
- Logistic regression using `liblinear` solver parameter
- Random Forest
- GaussianNB
- Decision Tree
- K-Nearest Neighbor

<div class="alert alert-danger alertdanger" style="margin-top: 20px">
<p><b>5a.</b>  Model Fitting. <b>15 marks</b></p>
</div> 


```python
# 5 marks for loading libraries
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
```


```python
# 10 marks for model training

# 1. Train LR model
lr = LogisticRegression(solver='liblinear', multi_class='ovr').fit(X_train, y_train)
# 2. Train RF model
rf = RandomForestClassifier(n_estimators = 10, criterion = 'entropy', random_state = 0).fit(X_train, y_train)
# 3. Train GNB model
gnb = GaussianNB().fit(X_train, y_train)
# 4. Train DT model
dt = DecisionTreeClassifier(criterion = 'entropy', random_state = 0).fit(X_train, y_train)
# 5. Train KNN model
knn = KNeighborsClassifier(n_neighbors = 5, metric = 'minkowski', p = 2).fit(X_train, y_train)
```

<div class="alert alert-danger alertdanger" style="margin-top: 20px">
<p><b>5b.</b>  Compute the predictions of the trained models. <b>5 marks</b></p>
</div>


```python
# 5 marks for making predictions

# Make LR predictions
lr_pred = lr.predict(X_test)
# Make RF predictions
rf_pred = rf.predict(X_test)
# Make GNB predictions
gnb_pred = gnb.predict(X_test)
# Make DT predictions
dt_pred = dt.predict(X_test)
# Make KNN predictions
knn_pred = knn.predict(X_test)
```

<div class="alert alert-danger alertdanger" style="margin-top: 20px">
<p><b>5c.</b>Evaluate model perfomance using Accuracy score, Classification Report and Confusion Matrix. <b>14 marks</b></p>
</div>

- Accuracy scores for all 5 models and view in a dataframe sorted by `accuracy_score`
- Classification report of the best model based on `accuracy score`
- Confusion matrix of the best model based on `accuracy score`


```python
# 3 marks for importing 3 metrics
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

# 5 marks
# Accuracy scores of the trained models 
results = pd.DataFrame({'Model_Name':['Logistic Regression', 
                                      'Random Forest',
                                      'Gaussian Naive Bayes',
                                      'Decision Tree',
                                      'K Nearest Neighbor'], 
                       'Accuracy_value':[accuracy_score(y_test, lr_pred), 
                                      accuracy_score(y_test, rf_pred), 
                                      accuracy_score(y_test, gnb_pred), 
                                      accuracy_score(y_test, dt_pred),
                                         accuracy_score(y_test, knn_pred)]})
# 2 marks for sorting

# Results sorted by accuracy value
results.sort_values(by="Accuracy_value", ignore_index=True, ascending=False)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Model_Name</th>
      <th>Accuracy_value</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Random Forest</td>
      <td>0.973684</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Gaussian Naive Bayes</td>
      <td>0.956140</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Logistic Regression</td>
      <td>0.938596</td>
    </tr>
    <tr>
      <th>3</th>
      <td>K Nearest Neighbor</td>
      <td>0.938596</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Decision Tree</td>
      <td>0.921053</td>
    </tr>
  </tbody>
</table>
</div>




```python
# 2 marks for classification repeort

# Compute classification report
print ('Random Forest: \n',classification_report(y_test, rf_pred))
```

    Random Forest: 
                   precision    recall  f1-score   support
    
               0       0.96      1.00      0.98        67
               1       1.00      0.94      0.97        47
    
        accuracy                           0.97       114
       macro avg       0.98      0.97      0.97       114
    weighted avg       0.97      0.97      0.97       114
    
    


```python
# 2 marks

# Compute confusion matrix
cm = confusion_matrix(y_test, rf_pred)
print ('Gaussian Naive Bayes: \n', cm)
```

    Gaussian Naive Bayes: 
     [[67  0]
     [ 3 44]]
    

======================================================================================================================
#### 6. Conclusion [6]

<div class="alert alert-danger alertdanger" style="margin-top: 20px">
<p><b>6a.</b> Interpret values obtained from the confusion matrix. <b>4 marks</b></p>
</div>

Comment: [4]

- The result of TP = 67 will be that the malignant cancer patients diagnosed with malignant cancer.
- The result of TN = 44 will be that begnin patients are actually having begnin cancer.
- The result of FP = 0 will be that those actually begnin cancer patients are predicted as malignamt cancer patients.
- The result of FN = 3 will be that those actual malignant cancer patients are predicted as begnin cancer patients.

<div class="alert alert-danger alertdanger" style="margin-top: 20px">
<p><b>6b.</b> Conclusive remarks on the best model. <b>2 marks</b></p>
</div>

So finally we have built our classification model and we can see that `Random Forest` classification algorithm gives the best results for our dataset. Well its not always applicable to every dataset. To choose our model we always need to analyze our dataset and then apply our machine learning model.

======================================================================================================================

### Thank you for completing this Examination!

## Main Contributor

Eddie Cheteni

### Other Contributors 

Matildah Chiruka

## Change Log

| Date (YYYY-MM-DD) | Version | Moderated By | Change Description                 |
| ----------------- | ------- | ------------ | ---------------------------------- |
| 2021-11-10        | 1.0     | Chiruka M.   |                                    |



```python

```
